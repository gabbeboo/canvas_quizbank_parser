# Riktad lista

En implementation av ADTn _Riktad Lista_ baserad på en enkel-länkad lista.

## Minneshantering och utskrift

Det mesta av hur gränsytan används med avseende på minneshantering och
utskrifter är analogt för hur [listimplementationen](../list/) fungerar.

