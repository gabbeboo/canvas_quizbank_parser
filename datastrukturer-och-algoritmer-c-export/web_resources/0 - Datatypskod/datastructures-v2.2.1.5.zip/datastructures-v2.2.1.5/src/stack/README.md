# Stack
En implementation av ADT:n _Stack_ implementerad som en enkellänkad lista.

## Minneshantering och utskrift

Det mesta av hur gränsytan används med avseende på minneshantering och
utskrifter är analogt för hur [listimplementationen](../list/) fungerar.

# Minimal working example

Se [stack_mwe1.c](stack_mwe1.c) och [stack_mwe2.c](stack_mwe2.c).
